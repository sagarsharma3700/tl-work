import React from "react";
import Table from "./Table";
const App = () => {
  return (
    <div>
      <Table/>
    </div>
  );
};
export default App;
