import {useEffect, useState} from 'react';

const Table=()=>{
    const [data ,setData]= useState([])
    const [check, setCheck]= useState([])
    useEffect(()=>{
       fetch("http://localhost:3000/sagar").then((result)=>{
        result.json().then((res)=>{
            // console.log(res,"nnnnnnnnnnnnnnn")
            setData(res)
        })
       })
    },[])
  const dataHandler=(checked)=>{
    setCheck([...check])
    if(checked == true){
        setCheck([...check])
    }
    else{
        setCheck([])
    }
    // setCheck([])
  }
  const btn=()=>{
    console.log(check) 
  }
 
    // async function fetchData(){
    //     let res=await axios.get("http://localhost:3000/sagar");
    //     console.log(res)
    // }
    return(
        <div>
            <table border="1" width="400">
            <tr>
                <td>ID</td>
                <td>NAME</td>
                <td>AGE</td>
                <td>OPERATION</td>
            
            </tr>
            {
                data.map((list)=>
                <tr>
                <td>{list.id}</td>
                <td>{list.name}</td>
                <td>{list .age}</td>
                <td><input type="checkbox" onChange={()=>{dataHandler(list.id)}}/></td>
                
            
            </tr>
                )
            }
            </table>
            <button style={{margin:10 , padding:10}} onClick={btn}>SUBMIT</button>
        </div>
    )
}
export default Table;